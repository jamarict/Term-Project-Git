# Term-Project-Git
Everything and Allthings TP
